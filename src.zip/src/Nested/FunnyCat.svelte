<script>
    const img1_alt = "funny cat"
    const img1 = "images/funny_cat.jpg"
</script>

<main>
    <img src={img1} alt=""/>
</main>

<style type="text/scss">
    img {
        width: 400px;
        height: auto;
    }
</style>